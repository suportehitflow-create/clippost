// Clipost — serviço em segundo plano. O site do Clipost pede "busque o @fulano" e a extensão abre o
// perfil numa janelinha sem foco (com a SUA sessão do Instagram), rola a grade sozinha e junta os
// posts que o próprio Instagram carrega (instagram-captura.js anota). No fim fecha a janela.

// Roda DENTRO da página do perfil (mundo da página): rola e devolve os posts anotados
async function coletarPerfil(limite) {
  const esperar = ms => new Promise(r => setTimeout(r, ms))
  // espera o anotador (instagram-captura.js) e a primeira leva de posts
  for (let i = 0; i < 40 && !(window.__clipostColeta && window.__clipostColeta.size); i++) await esperar(250)
  const vistos = window.__clipostColeta || new Map()
  // posts que já vieram embutidos no HTML (quando o Instagram manda assim)
  document.querySelectorAll('script[type="application/json"]').forEach(s => {
    if (s.textContent.includes('xdt_api__v1__feed__user_timeline_graphql_connection') && window.__clipostVarrer) {
      try { window.__clipostVarrer(JSON.parse(s.textContent)) } catch (e) {}
    }
  })
  let parado = 0, ultimo = vistos.size
  while ((!limite || vistos.size < limite) && parado < 6) {
    window.scrollTo(0, document.documentElement.scrollHeight)
    await esperar(1400)
    window.scrollBy(0, -200)
    await esperar(300)
    if (vistos.size === ultimo) parado++
    else { parado = 0; ultimo = vistos.size }
  }
  const melhorImagem = m => (m && m.image_versions2 && m.image_versions2.candidates && m.image_versions2.candidates[0] && m.image_versions2.candidates[0].url) || null
  const itens = [...vistos.values()].map(m => {
    const carrossel = m.media_type === 8
    const video = m.media_type === 2 ? m : carrossel ? (m.carousel_media || []).find(c => c.media_type === 2) : null
    const v = video && (video.video_versions || []).slice().sort((a, b) => (b.width || 0) - (a.width || 0))[0]
    const primeira = carrossel ? (m.carousel_media || [])[0] : null
    return {
      tipo: m.media_type === 2 ? 'reel' : carrossel ? 'carrossel' : 'post',
      url: (v && v.url) || melhorImagem(primeira || m),
      video: !!(v && v.url),
      permalink: `https://www.instagram.com/${m.media_type === 2 ? 'reel' : 'p'}/${m.code}/`,
      title: ((m.caption && m.caption.text) || '').replace(/\s+/g, ' ').trim().slice(0, 200),
      thumbnail: melhorImagem(m) || melhorImagem(primeira),
      view_count: m.play_count ?? m.ig_play_count ?? m.view_count ?? null,
      like_count: m.like_count ?? null,
      comment_count: m.comment_count ?? null,
      timestamp: m.taken_at ?? null,
      duration: (video && video.video_duration) ?? null,
    }
  })
  // dados do perfil pela descrição da página ("104M seguidores, 93 seguindo, 4,935 posts")
  const desc = (document.querySelector('meta[name="description"]') || {}).content || ''
  const num = t => {
    if (!t) return null
    const x = t.trim().toLowerCase()
    const n = parseFloat(x.replace(/[^\d.,]/g, '').replace(/[.,](?=\d{3}\b)/g, '').replace(',', '.'))
    if (isNaN(n)) return null
    return /mi|m$/.test(x) ? Math.round(n * 1e6) : /mil|k$/.test(x) ? Math.round(n * 1e3) : Math.round(n)
  }
  const seg = (desc.match(/([\d.,]+\s*(?:mi|mil|k|m)?)\s*(?:seguidores|followers)/i) || [])[1]
  const posts = (desc.match(/([\d.,]+\s*(?:mi|mil|k|m)?)\s*(?:posts|publicações)/i) || [])[1]
  return {
    perfil: {
      usuario: location.pathname.split('/').filter(Boolean)[0],
      nome: null,
      foto: (document.querySelector('meta[property="og:image"]') || {}).content || null,
      seguidores: num(seg),
      total_posts: num(posts),
    },
    itens: limite ? itens.slice(0, limite) : itens,
    logado: document.cookie.includes('ds_user_id'),
  }
}

async function abrirJanela(url, precisaRolar) {
  // até 12 posts: o Instagram já manda na carga da página, então a janela fica minimizada (invisível)
  if (!precisaRolar) return chrome.windows.create({ url, state: 'minimized', focused: false })
  // mais que isso: precisa rolar, e janela escondida não carrega mais posts. O Chrome exige a janela
  // pelo menos 50% dentro da tela: janelinha mínima no canto inferior direito, metade para fora
  const base = await chrome.windows.getLastFocused().catch(() => null)
  const lado = 200
  const left = base ? base.left + base.width - lado / 2 : 0
  const top = base ? base.top + base.height - lado / 2 : 0
  try {
    return await chrome.windows.create({ url, type: 'popup', focused: false, width: lado, height: lado, left, top })
  } catch (e) {
    // posição recusada (monitor diferente etc.): canto da janela atual, inteira
    return chrome.windows.create({ url, type: 'popup', focused: false, width: lado, height: lado, left: base ? base.left + base.width - lado : 0, top: base ? base.top + base.height - lado : 0 })
  }
}

async function pelaJanela(usuario, limite) {
  const janela = await abrirJanela(`https://www.instagram.com/${encodeURIComponent(usuario)}/?clipost=1`, !limite || limite > 12)
  const abaId = janela.tabs && janela.tabs[0] && janela.tabs[0].id
  try {
    await new Promise(res => {
      const pronto = (id, info) => { if (id === abaId && info.status === 'complete') { chrome.tabs.onUpdated.removeListener(pronto); res() } }
      chrome.tabs.onUpdated.addListener(pronto)
      setTimeout(() => { chrome.tabs.onUpdated.removeListener(pronto); res() }, 25000)
    })
    const [r] = await chrome.scripting.executeScript({ target: { tabId: abaId }, world: 'MAIN', func: coletarPerfil, args: [limite] })
    const dados = r && r.result
    if (!dados) throw new Error('Não consegui ler o perfil.')
    if (!dados.itens.length) {
      throw new Error(dados.logado
        ? 'O Instagram não mostrou posts desse perfil (privado, inexistente ou sem posts).'
        : 'Entre no Instagram neste navegador e tente de novo.')
    }
    return dados
  } finally {
    chrome.windows.remove(janela.id).catch(() => {})
  }
}

// ---------------- YouTube pelo IP de quem usa (plano quando o servidor é bloqueado) ----------------
// Pede os links do vídeo ao próprio YouTube como um app de celular/óculos VR (links diretos, sem
// assinatura), baixa vídeo e áudio daqui do navegador e sobe cada um no link de upload que o site deu.
const CLIENTES_YT = [
  { nome: 'ANDROID_VR', num: 28, versao: '1.60.19', extra: { androidSdkVersion: 32, deviceMake: 'Oculus', deviceModel: 'Quest 3', osName: 'Android', osVersion: '12L' } },
  { nome: 'IOS', num: 5, versao: '20.10.4', extra: { deviceMake: 'Apple', deviceModel: 'iPhone16,2', osName: 'iPhone', osVersion: '18.3.2.22D82' } },
  { nome: 'ANDROID', num: 3, versao: '20.10.38', extra: { androidSdkVersion: 34, osName: 'Android', osVersion: '14' } },
]

async function playerYouTube(videoId) {
  let motivo = 'o YouTube não liberou este vídeo'
  for (const c of CLIENTES_YT) {
    try {
      const r = await fetch('https://www.youtube.com/youtubei/v1/player?prettyPrint=false', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-YouTube-Client-Name': String(c.num), 'X-YouTube-Client-Version': c.versao },
        body: JSON.stringify({
          videoId, contentCheckOk: true, racyCheckOk: true,
          context: { client: { clientName: c.nome, clientVersion: c.versao, hl: 'pt', gl: 'BR', ...c.extra } },
        }),
      })
      const j = await r.json()
      const ok = j?.playabilityStatus?.status === 'OK'
      const temLinks = (j?.streamingData?.adaptiveFormats || []).some(f => f.url) || (j?.streamingData?.formats || []).some(f => f.url)
      if (ok && temLinks) return j
      motivo = j?.playabilityStatus?.reason || motivo
    } catch (e) {}
  }
  throw new Error(motivo)
}

// baixa em pedaços de 8 MB (o YouTube corta downloads grandes de uma vez só)
async function baixarStream(url, tamanho) {
  const partes = []
  const PASSO = 8 * 1024 * 1024
  if (!tamanho) {
    const r = await fetch(url)
    if (!r.ok) throw new Error(`download ${r.status}`)
    return await r.blob()
  }
  for (let ini = 0; ini < tamanho; ini += PASSO) {
    const fim = Math.min(tamanho, ini + PASSO) - 1
    let r
    for (let t = 0; t < 3; t++) {
      r = await fetch(`${url}&range=${ini}-${fim}`).catch(() => null)
      if (r && r.ok) break
      await new Promise(res => setTimeout(res, 1500 * (t + 1)))
    }
    if (!r || !r.ok) throw new Error(`download ${r ? r.status : 'rede'}`)
    partes.push(await r.blob())
  }
  return new Blob(partes)
}

async function subir(destino, blob, tipo) {
  const r = await fetch(destino, { method: 'PUT', headers: { 'Content-Type': tipo, 'x-upsert': 'true' }, body: blob })
  if (!r.ok) throw new Error(`upload ${r.status}`)
}

async function baixarYouTube(videoId, destinos) {
  const j = await playerYouTube(videoId)
  const sd = j.streamingData || {}
  const adapt = (sd.adaptiveFormats || []).filter(f => f.url)
  // vídeo MP4 (H.264) até 720p (arquivo menor para subir; o corte sai em 1080x1920 do mesmo jeito) e o melhor áudio M4A
  const videos = adapt.filter(f => /^video\/mp4/.test(f.mimeType || '') && (f.height || 0) <= 720)
    .sort((a, b) => (/avc1/.test(b.mimeType) - /avc1/.test(a.mimeType)) || (b.height || 0) - (a.height || 0) || (b.bitrate || 0) - (a.bitrate || 0))
  const audios = adapt.filter(f => /^audio\/mp4/.test(f.mimeType || '')).sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0))
  const info = { titulo: j.videoDetails?.title || '', duracao: Number(j.videoDetails?.lengthSeconds) || null }
  if (videos[0] && audios[0]) {
    const [v, a] = await Promise.all([
      baixarStream(videos[0].url, Number(videos[0].contentLength) || 0),
      baixarStream(audios[0].url, Number(audios[0].contentLength) || 0),
    ])
    await subir(destinos.video, v, 'video/mp4')
    await subir(destinos.audio, a, 'audio/mp4')
    return { ...info, audioSeparado: true, altura: videos[0].height }
  }
  // sem formatos separados: o arquivo único (vídeo + áudio juntos, qualidade menor)
  const unico = (sd.formats || []).filter(f => f.url && /^video\/mp4/.test(f.mimeType || '')).sort((a, b) => (b.height || 0) - (a.height || 0))[0]
  if (!unico) throw new Error('nenhum formato de vídeo disponível')
  await subir(destinos.video, await baixarStream(unico.url, Number(unico.contentLength) || 0), 'video/mp4')
  return { ...info, audioSeparado: false, altura: unico.height }
}

chrome.runtime.onMessage.addListener((msg, _remetente, responder) => {
  // extensão carregada da pasta: o Clipost pede para ela se recarregar quando houver versão nova
  if (msg?.tipo === 'RECARREGAR') {
    responder({ ok: true })
    setTimeout(() => chrome.runtime.reload(), 200)
    return
  }
  if (msg?.tipo === 'BAIXAR_YOUTUBE') {
    ;(async () => {
      try {
        responder({ ok: true, ...(await baixarYouTube(String(msg.videoId || ''), msg.destinos || {})) })
      } catch (e) {
        responder({ ok: false, erro: e?.message || String(e) })
      }
    })()
    return true
  }
  if (msg?.tipo !== 'BUSCAR_INSTAGRAM') return
  const usuario = String(msg.usuario || '').replace(/^@/, '').trim()
  const limite = Math.max(0, Math.min(Number(msg.limite) || 0, 3000))
  ;(async () => {
    try {
      responder({ ok: true, dados: await pelaJanela(usuario, limite) })
    } catch (e) {
      responder({ ok: false, erro: e?.message || String(e) })
    }
  })()
  return true // resposta assíncrona
})
